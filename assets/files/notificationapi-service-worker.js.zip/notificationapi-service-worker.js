// eslint-disable-next-line no-undef
importScripts(
  'https://cdn.jsdelivr.net/npm/notificationapi-js-client-sdk@latest/dist/service-worker.js'
);
